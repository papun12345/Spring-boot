package com.Test.myWebApp_Test;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApplicationTestSpring {

	public static void main(String[] args) {
		SpringApplication.run(ApplicationTestSpring.class, args);
	}

}
